const pool = require('../config/database');

const quizQuestions = {
  hollywood: [
    { question: 'Which movie won the Oscar for Best Picture in 2023?', options: ['Oppenheimer', 'Barbie', 'Killers of the Flower Moon', 'Poor Things'], answer: 0 },
    { question: 'Who directed "Inception"?', options: ['Steven Spielberg', 'Christopher Nolan', 'James Cameron', 'David Fincher'], answer: 1 },
    { question: 'Which actor played the Joker in "The Dark Knight"?', options: ['Joaquin Phoenix', 'Jack Nicholson', 'Heath Ledger', 'Jared Leto'], answer: 2 },
    { question: 'What is the highest-grossing film of all time?', options: ['Avengers: Endgame', 'Avatar', 'Titanic', 'Star Wars: The Force Awakens'], answer: 1 },
    { question: 'Which film features the song "My Heart Will Go On"?', options: ['The Bodyguard', 'Titanic', 'Romeo + Juliet', 'Moulin Rouge'], answer: 1 },
  ],
  marvel: [
    { question: 'What is the name of Thor\'s hammer?', options: ['Stormbreaker', 'Mjolnir', 'Gungnir', 'Nidavellir'], answer: 1 },
    { question: 'Which Infinity Stone is on Vision\'s forehead?', options: ['Time Stone', 'Space Stone', 'Mind Stone', 'Soul Stone'], answer: 2 },
    { question: 'Who is the first Avenger?', options: ['Iron Man', 'Captain America', 'Thor', 'Hulk'], answer: 1 },
    { question: 'What is Black Panther\'s real name?', options: ['M\'Baku', 'Killmonger', 'T\'Challa', 'Shuri'], answer: 2 },
    { question: 'Which movie introduced Spider-Man to the MCU?', options: ['Spider-Man: Homecoming', 'Captain America: Civil War', 'Avengers: Infinity War', 'Ant-Man'], answer: 1 },
  ],
  dc: [
    { question: 'Who is Batman\'s butler?', options: ['Alfred', 'Gordon', 'Robin', 'Joker'], answer: 0 },
    { question: 'What is Superman\'s home planet?', options: ['Mars', 'Krypton', 'Venus', 'Saturn'], answer: 1 },
    { question: 'Which DC hero is known as the "Fastest Man Alive"?', options: ['Green Lantern', 'The Flash', 'Aquaman', 'Cyborg'], answer: 1 },
    { question: 'Who directed "The Dark Knight" trilogy?', options: ['Zack Snyder', 'Christopher Nolan', 'Tim Burton', 'Patty Jenkins'], answer: 1 },
    { question: 'What is Wonder Woman\'s weapon called?', options: ['Shield of Athena', 'Lasso of Truth', 'Sword of Hephaestus', 'Spear of Destiny'], answer: 1 },
  ],
  anime: [
    { question: 'Which anime features a character named Goku?', options: ['Naruto', 'One Piece', 'Dragon Ball Z', 'Attack on Titan'], answer: 2 },
    { question: 'What is the name of the pirate crew in One Piece?', options: ['Red Hair Pirates', 'Straw Hat Pirates', 'Blackbeard Pirates', 'Whitebeard Pirates'], answer: 1 },
    { question: 'Which Studio created "Spirited Away"?', options: ['Madhouse', 'Studio Ghibli', 'Toei Animation', 'Bones'], answer: 1 },
    { question: 'Who is the main protagonist of "Attack on Titan"?', options: ['Levi', 'Eren', 'Mikasa', 'Armin'], answer: 1 },
    { question: 'What is Naruto\'s signature technique?', options: ['Chidori', 'Rasengan', 'Shadow Clone', 'Fireball Jutsu'], answer: 2 },
  ],
  bollywood: [
    { question: 'Which is the highest-grossing Bollywood film?', options: ['Dangal', 'Baahubali 2', 'Pathaan', 'Jawan'], answer: 1 },
    { question: 'Who directed "3 Idiots"?', options: ['Sanjay Leela Bhansali', 'Rajkumar Hirani', 'Karan Johar', 'Anurag Kashyap'], answer: 1 },
    { question: 'Which actor is known as "King Khan"?', options: ['Aamir Khan', 'Salman Khan', 'Shah Rukh Khan', 'Ranbir Kapoor'], answer: 2 },
    { question: 'What year was "Sholay" released?', options: ['1975', '1980', '1970', '1985'], answer: 0 },
    { question: 'Which film won India\'s first Oscar?', options: ['Slumdog Millionaire', 'Lagaan', 'Gandhi', 'Mother India'], answer: 0 },
  ],
};

const getQuizQuestions = async (req, res) => {
  try {
    const { category } = req.params;
    const questions = quizQuestions[category] || quizQuestions.hollywood;
    const shuffled = questions.sort(() => Math.random() - 0.5).slice(0, 5);
    const safeQuestions = shuffled.map(({ question, options }) => ({ question, options }));
    res.json(safeQuestions);
  } catch (error) {
    console.error('Quiz questions error:', error);
    res.status(500).json({ error: 'Failed to fetch quiz questions' });
  }
};

const submitQuiz = async (req, res) => {
  try {
    const { category, answers } = req.body;
    const questions = quizQuestions[category] || quizQuestions.hollywood;
    
    let score = 0;
    answers.forEach((answer, index) => {
      if (answer === questions[index]?.answer) score++;
    });

    await pool.query(
      'INSERT INTO quiz_scores (user_id, score, category) VALUES ($1, $2, $3)',
      [req.user.id, score, category]
    );

    res.json({ score, total: questions.length });
  } catch (error) {
    console.error('Submit quiz error:', error);
    res.status(500).json({ error: 'Failed to submit quiz' });
  }
};

const getLeaderboard = async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT u.name, u.avatar, MAX(qs.score) as best_score, COUNT(qs.id) as quizzes_taken
       FROM quiz_scores qs
       INNER JOIN users u ON qs.user_id = u.id
       GROUP BY u.id, u.name, u.avatar
       ORDER BY best_score DESC
       LIMIT 50`
    );
    res.json(result.rows);
  } catch (error) {
    console.error('Leaderboard error:', error);
    res.status(500).json({ error: 'Failed to fetch leaderboard' });
  }
};

module.exports = { getQuizQuestions, submitQuiz, getLeaderboard };