const pool = require('../config/database');

const getFavorites = async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT f.id, f.created_at,
              m.tmdb_id, m.title, m.poster, m.backdrop, m.rating, m.genre, m.release_date
       FROM favorites f
       INNER JOIN movies m ON f.movie_id = m.id
       WHERE f.user_id = $1
       ORDER BY f.created_at DESC`,
      [req.user.id]
    );
    res.json(result.rows);
  } catch (error) {
    console.error('Get favorites error:', error);
    res.status(500).json({ error: 'Failed to fetch favorites' });
  }
};

const addFavorite = async (req, res) => {
  try {
    const { tmdb_id } = req.body;
    
    const movieResult = await pool.query('SELECT id FROM movies WHERE tmdb_id = $1', [tmdb_id]);
    let movieId;
    if (movieResult.rows.length === 0) {
      const newMovie = await pool.query(
        'INSERT INTO movies (tmdb_id, title, poster) VALUES ($1, $2, $3) ON CONFLICT (tmdb_id) DO UPDATE SET tmdb_id = EXCLUDED.tmdb_id RETURNING id',
        [tmdb_id, req.body.title || '', req.body.poster || '']
      );
      movieId = newMovie.rows[0].id;
    } else {
      movieId = movieResult.rows[0].id;
    }

    const result = await pool.query(
      'INSERT INTO favorites (user_id, movie_id) VALUES ($1, $2) ON CONFLICT (user_id, movie_id) DO NOTHING RETURNING id',
      [req.user.id, movieId]
    );
    
    if (result.rows.length === 0) {
      return res.status(400).json({ error: 'Movie already in favorites' });
    }
    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error('Add favorite error:', error);
    res.status(500).json({ error: 'Failed to add favorite' });
  }
};

const removeFavorite = async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query(
      'DELETE FROM favorites WHERE id = $1 AND user_id = $2 RETURNING id',
      [id, req.user.id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Favorite not found' });
    }
    res.json({ message: 'Removed from favorites' });
  } catch (error) {
    console.error('Remove favorite error:', error);
    res.status(500).json({ error: 'Failed to remove favorite' });
  }
};

module.exports = { getFavorites, addFavorite, removeFavorite };