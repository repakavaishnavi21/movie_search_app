const pool = require('../config/database');

const getWatchlist = async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT w.id, w.status, w.progress, w.created_at,
              m.tmdb_id, m.title, m.poster, m.backdrop, m.rating, m.genre, m.release_date
       FROM watchlist w
       INNER JOIN movies m ON w.movie_id = m.id
       WHERE w.user_id = $1
       ORDER BY w.created_at DESC`,
      [req.user.id]
    );
    res.json(result.rows);
  } catch (error) {
    console.error('Get watchlist error:', error);
    res.status(500).json({ error: 'Failed to fetch watchlist' });
  }
};

const addToWatchlist = async (req, res) => {
  try {
    const { tmdb_id, status } = req.body;
    
    // Ensure movie exists in DB
    const movieResult = await pool.query('SELECT id FROM movies WHERE tmdb_id = $1', [tmdb_id]);
    let movieId;
    if (movieResult.rows.length === 0) {
      const newMovie = await pool.query(
        'INSERT INTO movies (tmdb_id, title, poster) VALUES ($1, $2, $3) ON CONFLICT (tmdb_id) DO UPDATE SET tmdb_id = EXCLUDED.tmdb_id RETURNING id',
        [tmdb_id, req.body.title || '', req.body.poster || '']
      );
      movieId = newMovie.rows[0].id;
    } else {
      movieId = movieResult.rows[0].id;
    }

    const result = await pool.query(
      `INSERT INTO watchlist (user_id, movie_id, status) 
       VALUES ($1, $2, $3) 
       ON CONFLICT (user_id, movie_id) 
       DO UPDATE SET status = EXCLUDED.status
       RETURNING id, status, progress`,
      [req.user.id, movieId, status || 'planned']
    );
    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error('Add to watchlist error:', error);
    res.status(500).json({ error: 'Failed to add to watchlist' });
  }
};

const updateWatchlistStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const { status, progress } = req.body;
    const result = await pool.query(
      `UPDATE watchlist SET 
        status = COALESCE($1, status),
        progress = COALESCE($2, progress)
       WHERE id = $3 AND user_id = $4
       RETURNING id, status, progress`,
      [status, progress, id, req.user.id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Watchlist entry not found' });
    }
    res.json(result.rows[0]);
  } catch (error) {
    console.error('Update watchlist error:', error);
    res.status(500).json({ error: 'Failed to update watchlist' });
  }
};

const removeFromWatchlist = async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query(
      'DELETE FROM watchlist WHERE id = $1 AND user_id = $2 RETURNING id',
      [id, req.user.id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Watchlist entry not found' });
    }
    res.json({ message: 'Removed from watchlist' });
  } catch (error) {
    console.error('Remove from watchlist error:', error);
    res.status(500).json({ error: 'Failed to remove from watchlist' });
  }
};

module.exports = { getWatchlist, addToWatchlist, updateWatchlistStatus, removeFromWatchlist };